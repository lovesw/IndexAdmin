CREATE FUNCTION func_split(f_string VARCHAR(1000), f_delimiter VARCHAR(5), f_order INT)
  RETURNS VARCHAR(255)
  BEGIN 
    # 拆分传入的字符串，返回拆分后的新字符串 
        declare result varchar(255) default ''; 
        set result = reverse(substring_index(reverse(substring_index(f_string,f_delimiter,f_order)),f_delimiter,1)); 
        return result; 
END;
