CREATE FUNCTION func_split_TotalLength(f_string VARCHAR(1000), f_delimiter VARCHAR(5))
  RETURNS INT
  BEGIN 
    # 计算传入字符串的总length 
    return 1+(length(f_string) - length(replace(f_string,f_delimiter,''))); 
END;
