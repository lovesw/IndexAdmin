CREATE PROCEDURE themesorts(IN f_string VARCHAR(1000), IN f_delimiter VARCHAR(5))
  BEGIN 
# 拆分结果 
declare cnt int default 0; 
declare i int default 0; 
set cnt = func_split_TotalLength(f_string,f_delimiter); 
DROP TABLE IF EXISTS `tmp_split`; 
create temporary table `tmp_split` (`status` varchar(128) not null) DEFAULT CHARSET=utf8; 
while i < cnt 
do 
    set i = i + 1; 
    update theme set sorts=i where id=func_split(f_string,f_delimiter,i); 
end while; 
END;
